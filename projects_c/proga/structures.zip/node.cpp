#include "node.h"
#include <stdlib.h>
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void add_to_list(NODE** head, POINT const* value)
{
	while (*head)
	{
		if (less(&(*head)->elem, value))
			head = &(*head)->next;
		else
			break;
	}
	NODE* new_elem = (NODE*)malloc(sizeof(NODE));
	new_elem->elem = *value;
	new_elem->next = *head;
	*head = new_elem;
}

void print_list(NODE const* head)
{
	while (head)
	{
		print_point(&(head->elem));
		head = head->next;
	}
}

void delete_from_list(NODE** head, POINT const* elem)
{
	while (*head)
	{
		if (is_equal_point(&(*head)->elem, elem))
			break;
		head = &(*head)->next;
	}
	NODE* temp = *head;
	*head = (*head)->next;
	free(temp);
}

void delete_list(NODE* head)
{
	if (head)
		delete_list(head->next);
	free(head);
}
