#ifndef NODE_H
#define NODE_h

#include "point.h"

typedef struct Node {
	POINT elem;
	struct Node* next;
}NODE;

void add_to_list(NODE** head, POINT const * elem);
void print_list(NODE const* head);
void delete_from_list(NODE** head, POINT const* elem);
void delete_list(NODE* head);

#endif
