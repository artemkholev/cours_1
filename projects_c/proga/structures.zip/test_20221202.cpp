#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "point.h"
#include "node.h"

#define TASK_2

#ifdef TASK_1
int main()
{
	//struct Point p;
	POINT p = { 1,2,"green"};
	print_point(&p);
	POINT p2;
	p2 = p;
	print_point(&p2);
	if (is_equal(&p, &p2))
		printf("equal\n");
	else
		printf("not equal\n");
	p.x = 0;
	p.y = 0;
	p2.x = 3;
	p2.y = 4;
	print_point(&p);
	print_point(&p2);
	printf("Distance is %.2lf\n", calculate_distance(&p, &p2));
}
#endif //TASK_1

#ifdef TASK_2
int main()
{
	srand((unsigned)time(0));
	char colors[][SIZE] = { "red", "green", "blue", "violet", "black",
							"yellow", "white", "brown", "orange", "cian"};
	NODE* head = NULL;
	POINT p = { 0.001,0.0020,"" };
	strcpy(p.color, colors[0]);
	add_to_list(&head, &p);
	//print_list(head);

	for (int i = 0; i < 3; ++i)
	{
		double x = (double)(rand()) / (rand() + 1);
		double y = (double)(rand()) / (rand() + 1);
		int index = rand() % 10;
		POINT p = { x,y,""};
		strcpy(p.color, colors[index]);
		add_to_list(&head, &p);
	}
	print_list(head);
	/*POINT p = { 10,20,""};
	strcpy(p.color, colors[0]);
	add_to_list(&head, &p);
	print_list(head);*/
	delete_from_list(&head, &p);
	print_list(head);
	delete_list(head);
	head = NULL;
	print_list(head);
	return 0;
}
#endif TASK_2

