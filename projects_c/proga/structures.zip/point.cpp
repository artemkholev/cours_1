#include "point.h"
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>

void print_point(POINT const* p)
{
	//[1.00, 2.00]
	printf("coord = [%.2lf, %.2lf]\n", p->x, p->y);
	printf("color = %s\n", p->color);
	//printf("[%.2lf, %.2lf]\n", (*p).x, (*p).y);
}

int is_equal_point(POINT const* p1, POINT const* p2)
{
	return p1->x == p2->x && p1->y == p2->y && !strcmp(p1->color,p2->color);
}

double calculate_distance(POINT const* p1, POINT const* p2)
{
	return sqrt(pow(p1->x-p2->x, 2)+pow(p1->y-p2->y,2));

}

int less(POINT const* p1, POINT const* p2)
{
	POINT zero = { 0,0 };
	double x1 = calculate_distance(&zero, p1);
	double x2 = calculate_distance(&zero, p2);
	return x1 < x2;
}
