//#pragma once

#ifndef POINT_H
#define POINT_H

#define SIZE 20
typedef struct Point
{
	double x, y;
	char color[SIZE];
}POINT;

void print_point(POINT const* p);
int is_equal_point(POINT const* p1, POINT const* p2);
double calculate_distance(POINT const* p1, POINT const* p2);
int less(POINT const* p1, POINT const* p2);

#endif